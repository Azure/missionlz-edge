#-----------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
#-----------------------------------------------------------------------

# .EXTERNALHELP Import.psm1-Help.xml

function Import-AzsMarketplaceItem {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [bool] $isFileShare = $true,

        [Parameter(Mandatory = $true)]
        [string] $RepositoryDir,

        [Parameter(Mandatory = $false)]
        [string] $JournalDir,

        [Parameter(Mandatory = $false)]
        [string[]] $ProductName,

        [Parameter(Mandatory = $false)]
        [string] $SourceContainerName = "temp",

        [Parameter(Mandatory = $false)]
        [ValidateSet('Upload', 'Import', 'Cleanup')]
        [string] $From = 'Initialize',

        [Parameter(Mandatory = $false)]
        [ValidateSet('Upload', 'Import', 'Cleanup')]
        [string] $UpTo = 'Cleanup',

        [Parameter(Mandatory = $false)]
        [ValidateRange(5, 60)]
        [int] $SleepInterval = 60
    )

    function Upload-AllProducts {
        param ()

        function Initialize-StorageAccount {
            param ()

            Start-Activity 'Initialize-StorageAccount'

            Select-AzSubscription -Subscription 'Default Provider Subscription' -ErrorAction Stop | Out-Null

            New-AzResourceGroup -Name $ResourceGroupName -Location $Location -Force -ErrorAction Stop | Out-Null

            $sa = Get-AzStorageAccount -ResourceGroupName $ResourceGroupName -Name $StorageAccountName -ErrorAction SilentlyContinue

            if (-not $sa) {
                $sa = New-AzStorageAccount -ResourceGroupName $ResourceGroupName -Name $StorageAccountName -Location $Location -SkuName Standard_LRS -ErrorAction Stop
            }

            Stop-Activity

            return $sa.Context.ConnectionString
        }

        function Invoke-Upload {
            param (
                [ValidateNotNullOrEmpty()]
                [string] $ConnectionString
            )

            Start-Activity 'Invoke-Upload'

            while ($true) {
                if($IsWindows) {
                    & "$PSScriptRoot\SyndicationClient.exe" upload $RepositoryDir $JournalDir $ConnectionString
                } else {
                    Invoke-Expression "/bin/env -- '$PSScriptRoot/SyndicationClient' 'upload' '$RepositoryDir' '$JournalDir' '$ConnectionString'"
                }
                if ($LASTEXITCODE -eq 0) {
                    break
                }

                Write-Verbose "Sleep for $SleepInterval seconds" -Verbose
                Start-Sleep -Seconds $SleepInterval
            }

            Stop-Activity
        }

        function Invoke-Copy {
            param (
                [ValidateNotNullOrEmpty()]
                [string] $SourceConnectionString,

                [ValidateNotNullOrEmpty()]
                [string] $DestinationConnectionString,

                [ValidateNotNullOrEmpty()]
                [string] $SourceContainerName
            )

            Start-Activity 'Invoke-Copy'

            while ($true) {                
                if($IsWindows) {
                    & "$PSScriptRoot\SyndicationClient.exe" copy $JournalDir $SourceConnectionString $DestinationConnectionString $SourceContainerName
                } else {
                    Invoke-Expression "/bin/env -- '$PSScriptRoot/SyndicationClient' 'copy' '$JournalDir' '$SourceConnectionString' '$DestinationConnectionString' '$SourceContainerName'"
                }
                if ($LASTEXITCODE -eq 0) {
                    break
                }

                Write-Verbose "Sleep for $SleepInterval seconds" -Verbose
                Start-Sleep -Seconds $SleepInterval
            }

            Stop-Activity
        }

        #-----------------------------------------------------------------------

        function Upload-AllProducts {
            Start-Activity 'Upload-AllProducts'

            $productList = Get-ProductList -ProductNames $ProductName

            $uploadJobInfo = @{
                productNames = @() + ($productList | ForEach-Object { $_.ProductName })
            }
            $uploadJobInfo | ConvertTo-Json -Depth 99 | Set-Content -LiteralPath "$JournalDir\.import-info.json" -Encoding UTF8

            $connectionString = Initialize-StorageAccount

            Invoke-Upload -ConnectionString $connectionString

            Stop-Activity
        }

        function Copy-AllProducts {
            Start-Activity 'Copy the blobs from the Storage account'

            Download-ProductDetails -ProductNames $ProductName

            $productList = Get-ProductList-FromBlob -ProductNames $ProductName

            $copyJobInfo = @{
                productNames = @() + ($productList | ForEach-Object { $_.ProductName })
            }

            $copyJobInfo | ConvertTo-Json -Depth 99 | Set-Content -LiteralPath "$JournalDir\.import-info.json" -Encoding UTF8


            $DestinationConnectionString = Initialize-StorageAccount
            $sourceConnectionString = $RepositoryDir

            Invoke-Copy -SourceConnectionString $sourceConnectionString -DestinationConnectionString $DestinationConnectionString -SourceContainerName $SourceContainerName

            Stop-Activity
        }
       
        if($isFileShare)
        {
            # if the path to the file share is given , then upload the products into the syndicationtempsa Storage Account
            Upload-AllProducts
        }
        else {
            # if the url of the deployment package is given , then copy the products into the syndicationtempsa Storage Account
            Copy-AllProducts
        }       
    }

    #-----------------------------------------------------------------------

    function Import-AllProducts {
        param ()

        function Import-Product {
            param (
                [psobject] $ProductDetails
            )

            Start-Activity "Import-Product, productName = $($ProductDetails.ProductName)"

            $productId = "$ActivationResourceId/downloadedProducts/$($productDetails.ProductName)"
            $requestUri = "$($productId)?api-version=2016-01-01"
            $response = Invoke-AzsResourceManager -Method GET -Uri $requestUri

            if ($response.StatusCode -eq [System.Net.HttpStatusCode]::NotFound) {
                $product = $null
            }
            else {
                Ensure-SuccessStatusCode -Response $response
                $product = $response.Content | ConvertFrom-Json
            }

            Write-Verbose "Provisioning state of $($productDetails.ProductName): $($product.properties.provisioningState)" -Verbose

            if (-not $product -or $product.properties.provisioningState -eq 'Failed') {
                Write-Verbose 'Initializing product import...' -Verbose

                $requestUri = "$($productId)?api-version=2016-01-01"
                $payload = Get-Content -LiteralPath "$JournalDir\$($productDetails.ProductName)\payload.json" -Raw | ConvertFrom-Json
                Invoke-AzsResourceManager -Method PUT -Uri $requestUri -Body @{ properties = $payload; } -ThrowOnError | Out-Null
            }

            Stop-Activity
        }

        function Wait-ForProducts {
            param (
                [psobject[]] $ProductList
            )

            Start-Activity 'Wait-ForProducts'

            $timeout = [timespan]::FromHours(6)
            $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()

            while ($true) {
                Write-Verbose "[$(Get-Date -Format 's')] Get product import status" -Verbose

                $allDone = $true

                foreach ($productDetails in $ProductList) {
                    $productId = "$ActivationResourceId/downloadedProducts/$($productDetails.ProductName)"
                    $requestUri = "$($productId)?api-version=2016-01-01"
                    $response = Invoke-AzsResourceManager -Method GET -Uri $requestUri -ThrowOnError
                    $product = $response.Content | ConvertFrom-Json

                    Write-Verbose "Provisioning state of $($productDetails.ProductName): $($product.properties.provisioningState)" -Verbose

                    if ($product.properties.provisioningState -eq 'Failed') {
                        throw "Failed to import product, productId: $productId."
                    }

                    if ($product.properties.provisioningState -ne 'Succeeded') {
                        $allDone = $false
                    }
                }

                if ($allDone) {
                    break
                }

                if ($stopwatch.Elapsed -gt $timeout) {
                    throw 'Product import didn''t complete within the allotted time.'
                }

                Write-Verbose "Sleep for $SleepInterval seconds" -Verbose
                Start-Sleep -Seconds $SleepInterval
            }

            Stop-Activity
        }

        #-----------------------------------------------------------------------

        Start-Activity 'Import-AllProducts'

        $importJobInfo = Get-Content "$JournalDir\.import-info.json" -Raw | ConvertFrom-Json

        if($isFileShare){
            $productList = Get-ProductList -ProductNames $importJobInfo.productNames
        }
        else {
            $productList = Get-ProductList-FromBlob -ProductNames $importJobInfo.productNames
        }

        foreach ($productDetails in $productList) {
            Import-Product -ProductDetails $productDetails
        }

        Wait-ForProducts -ProductList $productList

        Stop-Activity
    }

    #-----------------------------------------------------------------------

    function Invoke-Cleanup {
        param ()

        Start-Activity 'Invoke-Cleanup'

        $rg = Get-AzResourceGroup -Name $ResourceGroupName -Location $Location -ErrorAction SilentlyContinue

        if ($rg) {
            Remove-AzResourceGroup -Name $ResourceGroupName -Force
        }

        if (Test-Path $JournalDir) {
            Remove-Item $JournalDir -Recurse -Force
        }

        Stop-Activity
    }

    #-----------------------------------------------------------------------

    function Resolve-Activation {
        param ()

        $activation = Get-AzResource -ResourceType Microsoft.AzureBridge.Admin/activations | Select-Object -First 1

        if (-not $activation) {
            throw 'Azure Stack activation not found. Make sure your stamp is activated and the selected subscription is ''Default Provider Subscription''.'
        }

        return $activation.ResourceId
    }

    function Get-ProductList {
        param (
            [string[]]$ProductNames
        )

        $products = @()

        if ($ProductNames) {
            $productDirs = $ProductNames | ForEach-Object { [System.IO.Path]::Combine($RepositoryDir, $_) }
        }
        else {
            $productDirs = Get-ChildItem -LiteralPath $RepositoryDir -Directory | ForEach-Object { $_.FullName }
        }

        foreach ($productDir in $productDirs) {
            $productDetailsFileName = [System.IO.Path]::Combine($productDir, "productDetails.json")
            $productDetails = Get-Content -LiteralPath $productDetailsFileName -Raw | ConvertFrom-Json
            $products += $productDetails
        }

        return $products
    }

    function Download-ProductDetails {
        param (
            [string[]]$ProductNames
        ) 
        
        foreach($ProductName in $ProductNames){

            $productDetailsBlob = $srcContainer.GetBlobReference("$($ProductName)\productDetails.json")

            $productDir = "$JournalDir\$ProductName"
            New-Item -Path $productDir -ItemType Directory -Force | Out-Null
        
            $fileMode = [System.IO.FileMode]::Create
            $task = $productDetailsBlob.DownloadToFileAsync("$($productDir)\productDetails.json" , $fileMode)
            $null = $task.GetAwaiter().GetResult()
        }
    }
    function Get-ProductList-FromBlob {
        param (
            [string[]]$ProductNames
        )

        $products = @()

        foreach($ProductName in $ProductNames){
            $productDir = "$JournalDir\$ProductName"
            $productDetailsFileName = [System.IO.Path]::Combine($productDir, "productDetails.json")
            $productDetails = Get-Content -LiteralPath $productDetailsFileName -Raw | ConvertFrom-Json
            $products += $productDetails            
        }

        return $products
    }

    function Get-ProductNameList-FromBlob {
        [Microsoft.WindowsAzure.Storage.Blob.BlobContinuationToken ]$token = $null

        $results = $srcContainer.ListBlobsSegmentedAsync($token)

        $productNames = $results.Result.Results

        $productNameEntities = @()
        foreach ($productName in $productNames) {
            if ([bool]($productName.PSobject.Properties.name -match "Prefix")) {
                $productName = $productName.Prefix.Trim('/')
                if([bool]($srcContainer.GetBlobReference("$productName\productDetails.json").ExistsAsync().Result)) {
                    $productNameEntities += $productName
                }
            }
        }

        return $productNameEntities
    }

    #-----------------------------------------------------------------------

    $Steps = @{
        Upload = 0
        Import = 1
        Cleanup = 2
    }
    $FromValue = $Steps[$From]
    $UpToValue = $Steps[$UpTo]

    $Location = (Get-AzLocation)[0].Location
    $ResourceGroupName = 'syndicationtemp-rg'
    $StorageAccountName = 'syndicationtempsa'

    if($isFileShare){
        $RepositoryDir = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($RepositoryDir)
        New-Item -Path $RepositoryDir -ItemType Directory -Force | Out-Null
        Write-Verbose "RepositoryDir: $RepositoryDir" -Verbose
    }

    if (-not $JournalDir) {
        $JournalDir = [System.IO.Path]::Combine([System.IO.Path]::GetTempPath(), [guid]::NewGuid().ToString())
    }
    else {
        $JournalDir = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($JournalDir)
    }
    New-Item -Path $JournalDir -ItemType Directory -Force | Out-Null

    $ActivationResourceId = Resolve-Activation

    if(-not $isFileShare){
        Write-Verbose "Importing the blobs from the container : $SourceContainerName" -Verbose

        Add-Type -Path "Microsoft.WindowsAzure.Storage.dll"
        $storageAccount = [Microsoft.WindowsAzure.Storage.CloudStorageAccount]::Parse($RepositoryDir)
        $srcContainer = $storageAccount.CreateCloudBlobClient().GetContainerReference($SourceContainerName)

        if ($null -eq $ProductName){
            Write-Verbose "Fetching the product names from the blob" -Verbose
            $ProductName = Get-ProductNameList-FromBlob
        }
    }

    Start-Activity 'Import'

    Write-Verbose "JournalDir: $JournalDir" -Verbose

    if ($FromValue -le $Steps.Upload -and $UpToValue -ge $Steps.Upload) {
        Upload-AllProducts
    }

    if ($FromValue -le $Steps.Import -and $UpToValue -ge $Steps.Import) {
        Import-AllProducts
    }

    if ($FromValue -le $Steps.Cleanup -and $UpToValue -ge $Steps.Cleanup) {
        Invoke-Cleanup
    }

    Stop-Activity
}

#-----------------------------------------------------------------------

$ErrorActionPreference = 'Stop'
$InformationPreference = 'Continue'

Import-Module "$PSScriptRoot\Activities.psm1" -Force -ErrorAction Stop
Import-Module "$PSScriptRoot\ResourceManager.psm1" -Force -DisableNameChecking -ErrorAction Stop

Export-ModuleMember -Function @('Import-AzsMarketplaceItem')
