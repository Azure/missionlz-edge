#-----------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
#-----------------------------------------------------------------------

# .EXTERNALHELP Select.psm1-Help.xml

function Select-AzsMarketplaceItem {
    [CmdletBinding()]
    param ()

    #-----------------------------------------------------------------------

    Write-Verbose 'Retrieving list of registrations.' -Verbose

    $registrations = Get-AzResource -ResourceType Microsoft.AzureStack/registrations

    $displayRegistrations = $registrations | Select-Object ResourceGroupName,Name,ResourceId

    $registration = $displayRegistrations | Out-GridView -Title 'Please select registration resource' -OutputMode Single

    if (-not $registration) {
        throw 'You must select registration resource representing your stamp to continue.'
    }

    #-----------------------------------------------------------------------

    Write-Verbose 'Retrieving list of available products.' -Verbose

    $products = Get-AzResource -ResourceId "$($registration.ResourceId)/products"

    $displayProducts = $products | ForEach-Object {
        [pscustomobject][ordered]@{
            Name = $_.Properties.displayName
            Publisher = $_.Properties.publisherDisplayName
            Type = $_.Properties.productKind
            Version = $_.Properties.productProperties.version
            ResourceId = $_.ResourceId
        }
    } | Sort-Object Name,Publisher,Version

    return $displayProducts | Out-GridView -Title 'Please select product(s) to export' -PassThru | ForEach-Object { $_.ResourceId }
}

#-----------------------------------------------------------------------

$ErrorActionPreference = 'Stop'
$InformationPreference = 'Continue'

Export-ModuleMember -Function @('Select-AzsMarketplaceItem')
