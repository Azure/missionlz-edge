#-----------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
#-----------------------------------------------------------------------

$ErrorActionPreference = 'Stop'
$InformationPreference = 'Continue'

Import-Module "$PSScriptRoot\Export.psm1" -Force -ErrorAction Stop
Import-Module "$PSScriptRoot\Import.psm1" -Force -ErrorAction Stop
Import-Module "$PSScriptRoot\Select.psm1" -Force -ErrorAction Stop

Export-ModuleMember -Function @('Export-AzsMarketplaceItem', 'Import-AzsMarketplaceItem', 'Select-AzsMarketplaceItem')
