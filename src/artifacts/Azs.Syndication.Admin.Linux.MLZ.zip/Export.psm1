#-----------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
#-----------------------------------------------------------------------

# .EXTERNALHELP Export.psm1-Help.xml

function Export-AzsMarketplaceItem {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [string[]] $ProductId,

        [Parameter(Mandatory = $true)]
        [string] $RepositoryDir,

        [Parameter(Mandatory = $false)]
        [string] $JournalDir,

        [Parameter(Mandatory = $false)]
        [switch] $IgnoreDependencies,

        [Parameter(Mandatory = $false)]
        [switch] $AcceptLegalTerms,

        [Parameter(Mandatory = $false)]
        [ValidateSet('Resolve', 'Download', 'Cleanup')]
        [string] $From = 'Resolve',

        [Parameter(Mandatory = $false)]
        [ValidateSet('Resolve', 'Download', 'Cleanup')]
        [string] $UpTo = 'Cleanup',

        [Parameter(Mandatory = $false)]
        [ValidateRange(5, 60)]
        [int] $SleepInterval = 60
    )

    begin {
        $productQueue = [System.Collections.Queue]::new()
    }

    process {
        $ProductId | ForEach-Object { $productQueue.Enqueue($_) }
    }

    end {
        function Resolve-AllProducts {
            param ()

            function Resolve-ProductDetails {
                param (
                    [ValidateNotNullOrEmpty()]
                    [string] $ProductId
                )

                $productName = $ProductId.Split('/')[-1]

                Start-Activity "Resolve-ProductDetails, productName: $ProductName"

                try
                {
                    $productDetailsDir = "$RepositoryDir\$productName"
                    $productDetailsFileName = "$productDetailsDir\productDetails.json"

                    if (Test-Path -Path $productDetailsFileName) {
                        Write-Verbose "Retriving product details from cache: $ProductName" -Verbose

                        $productDetails = Get-Content -Path $productDetailsFileName -Raw | ConvertFrom-Json

                        if (-not (Test-IsStale -ProductDetails $productDetails)) {
                            return $productDetails
                        }

                        Write-Verbose "Product details is stale: $ProductName" -Verbose
                    }

                    Write-Verbose "Retriving details from the Cloud: $ProductName" -Verbose

                    $productDetails = Get-ProductDetails -ProductName $productName -ProductId $ProductId

                    if ($productDetails.Properties.legalTerms -and -not $AcceptLegalTerms.ToBool()) {
                        Display-LegalTerms -ProductDetails $productDetails
                    }

                    New-Item -Path $productDetailsDir -ItemType Directory -Force | Out-Null
                    $productDetails | ConvertTo-Json -Depth 99 | Set-Content -LiteralPath $productDetailsFileName -Encoding UTF8

                    return $productDetails
                }
                finally {
                    Stop-Activity
                }
            }

            function Test-IsStale {
                param (
                    [ValidateNotNull()]
                    [psobject] $ProductDetails
                )

                $timestamp = [datetime]::ParseExact($ProductDetails.Timestamp, 'G', [System.Globalization.CultureInfo]::InvariantCulture, [System.Globalization.DateTimeStyles]::AdjustToUniversal)

                if ([datetime]::UtcNow - $timestamp -gt [timespan]::FromDays(1)) {
                    return $true
                }

                return $false
            }

            function Get-ProductDetails {
                param (
                    [ValidateNotNullOrEmpty()]
                    [string] $ProductName,

                    [ValidateNotNullOrEmpty()]
                    [string] $ProductId
                )

                $productDetails = [psobject]::new()
                $productDetails | Add-Member -MemberType NoteProperty -Name 'ProductName' -Value $ProductName
                $productDetails | Add-Member -MemberType NoteProperty -Name 'Timestamp' -Value ([datetime]::UtcNow.ToString('o'))

                $resourceDefinition = Get-AzResource -ResourceId $ProductId -ApiVersion 2016-01-01
                $productDetails | Add-Member -MemberType NoteProperty -Name 'ResourceId' -Value $resourceDefinition.ResourceId
                $productDetails | Add-Member -MemberType NoteProperty -Name 'Properties' -Value $resourceDefinition.Properties

                $details = Invoke-AzResourceAction -ResourceId $ProductId -Action listDetails -ApiVersion 2016-01-01 -Force
                $productDetails | Add-Member -MemberType NoteProperty -Name 'Details' -Value $details

                $artifacts = Get-ProductArtifacts -ProductDetails $productDetails
                $productDetails | Add-Member -MemberType NoteProperty -Name 'Artifacts' -Value $artifacts

                return $productDetails
            }

            function Get-ProductArtifacts {
                param (
                    [ValidateNotNull()]
                    [psobject] $ProductDetails
                )

                $artifacts = @()

                if ($ProductDetails.Properties.iconUris.hero) {
                    $artifacts += New-ArtifactDescriptor -SourceUri $ProductDetails.Properties.iconUris.hero -Type Icon -RelativeDir 'icons\hero'
                }

                if ($ProductDetails.Properties.iconUris.large) {
                    $artifacts += New-ArtifactDescriptor -SourceUri $ProductDetails.Properties.iconUris.large -Type Icon -RelativeDir 'icons\large'
                }

                if ($ProductDetails.Properties.iconUris.medium) {
                    $artifacts += New-ArtifactDescriptor -SourceUri $ProductDetails.Properties.iconUris.medium -Type Icon -RelativeDir 'icons\medium'
                }

                if ($ProductDetails.Properties.iconUris.small) {
                    $artifacts += New-ArtifactDescriptor -SourceUri $ProductDetails.Properties.iconUris.small -Type Icon -RelativeDir 'icons\small'
                }

                if ($ProductDetails.Properties.iconUris.wide) {
                    $artifacts += New-ArtifactDescriptor -SourceUri $ProductDetails.Properties.iconUris.wide -Type Icon -RelativeDir 'icons\wide'
                }

                if ($ProductDetails.Properties.galleryItemIdentity) {
                    $artifacts += New-ArtifactDescriptor -SourceUri $ProductDetails.Details.galleryPackageBlobSasUri -Type GalleryPackage -RelativeDir 'galleryPackage'
                }

                $productKind = $ProductDetails.Properties.productKind

                switch ($productKind) {
                    { $_ -eq 'VirtualMachine'} {
                        $artifacts += New-ArtifactDescriptor -SourceUri $ProductDetails.Details.properties.osDiskImage.sourceBlobSasUri -Type VMDiskImage -RelativeDir 'osDiskImage'

                        foreach ($dataDiskImage in $ProductDetails.Details.properties.dataDiskImages) {
                            $artifacts += New-ArtifactDescriptor -SourceUri $dataDiskImage.sourceBlobSasUri -Type VMDiskImage -RelativeDir "dataDiskImages\$($dataDiskImage.lun)"
                        }

                        break
                    }

                    { $_ -eq 'VirtualMachineExtension' } {
                        $artifacts += New-ArtifactDescriptor -SourceUri $ProductDetails.Details.properties.sourceBlob.uri -Type VMExtensionPackage -RelativeDir 'extension'
                        break
                    }

                    { $_ -eq 'ResourceProvider' -or $_ -eq 'Solution'} {
                        foreach ($fileContainer in $ProductDetails.Details.properties.fileContainers) {
                            $artifacts += New-ArtifactDescriptor -SourceUri $fileContainer.sourceUri -Type FileContainer -RelativeDir ([System.IO.Path]::Combine('fileContainers', $fileContainer.id))
                        }

                        break
                    }

                    default {
                        throw "Product kind '$productKind' is invalid or not supported."
                    }
                }

                return $artifacts
            }

            function New-ArtifactDescriptor {
                param (
                    [ValidateNotNullOrEmpty()]
                    [string] $SourceUri,

                    [ValidateSet('Icon', 'GalleryPackage', 'VMDiskImage', 'VMExtensionPackage', 'FileContainer')]
                    [string] $Type,

                    [ValidateNotNullOrEmpty()]
                    [string] $RelativeDir
                )

                $fileName = [System.IO.Path]::GetFileName([uri]::new($SourceUri, [System.UriKind]::Absolute).AbsolutePath)

                if ([string]::IsNullOrEmpty($fileName)) {
                    throw "Unable to resolve file name, sourceUri: '$SourceUri'."
                }

                $artifact = [psobject]::new()
                $artifact | Add-Member -MemberType NoteProperty -Name SourceUri -Value $SourceUri
                $artifact | Add-Member -MemberType NoteProperty -Name Type -Value $Type
                $artifact | Add-Member -MemberType NoteProperty -Name RelativeFileName -Value ([System.IO.Path]::Combine($RelativeDir, $fileName))

                return $artifact
            }

            function New-DependentProductId {
                param (
                    [ValidateNotNullOrEmpty()]
                    [string] $OriginalProductId,

                    [ValidateNotNullOrEmpty()]
                    [string] $DependentProductName
                )

                $segments = $OriginalProductId.Split('/')
                $segments[-1] = $DependentProductName
                return $segments -join '/'
            }

            function Display-LegalTerms {
                param (
                    [ValidateNotNull()]
                    [psobject] $ProductDetails
                )

                Write-Host "------- Legal Terms: $($productDetails.Properties.displayName)" -ForegroundColor DarkYellow
                Write-Host $productDetails.Properties.legalTerms -ForegroundColor DarkYellow
                Write-Host '-------' -ForegroundColor DarkYellow

                while ($true) {
                    $result = Read-Host -Prompt 'Accept Legal Terms (Y/N)?'

                    if ($result -eq 'Y') {
                        break
                    }

                    if ($result -eq 'N') {
                        throw 'You must accept Legal Terms to download this software.'
                    }
                }
            }

            #-----------------------------------------------------------------------

            Start-Activity 'Resolve-AllProducts'

            $processedIds = @{}
            $productNames = @()

            while ($productQueue.Count -gt 0) {
                $productId = $productQueue.Dequeue()

                if ($processedIds.ContainsKey($productId)) {
                    continue
                }

                $productDetails = Resolve-ProductDetails -ProductId $productId

                $processedIds.Add($productId, $true)
                $productNames += $productDetails.ProductName

                if (-not $IgnoreDependencies.ToBool()) {
                    if ($productDetails.Details.properties.dependentProducts) {
                        foreach ($dependentProductName in $productDetails.Details.properties.dependentProducts) {
                            $productQueue.Enqueue((New-DependentProductId -OriginalProductId $productId -DependentProductName $dependentProductName))
                        }
                    }
                }
            }

            @{
                productNames = $productNames
            } | ConvertTo-Json -Depth 99 | Set-Content -LiteralPath "$JournalDir\.download-info.json" -Encoding UTF8

            Stop-Activity
        }

        #-----------------------------------------------------------------------

        function Download-AllProducts {
            param ()

            Start-Activity 'Download-AllProducts'

            while ($true) {
                if($IsWindows) {
                    & "$PSScriptRoot\SyndicationClient.exe" download $RepositoryDir $JournalDir
                } else {
                    Invoke-Expression "/bin/env -- '$PSScriptRoot/SyndicationClient' 'download' '$RepositoryDir' '$JournalDir'"
                }
                if ($LASTEXITCODE -eq 0) {
                    break
                }

                Write-Verbose "Sleep for $SleepInterval seconds" -Verbose
                Start-Sleep -Seconds $SleepInterval
            }

            Stop-Activity
        }

        #-----------------------------------------------------------------------

        function Invoke-Cleanup {
            param ()

            Start-Activity 'Invoke-Cleanup'

            if (Test-Path $JournalDir) {
                Remove-Item $JournalDir -Recurse -Force
            }

            Stop-Activity
        }

        #-----------------------------------------------------------------------

        $Steps = @{
            Resolve = 0
            Download = 1
            Cleanup = 2
        }
        $FromValue = $Steps[$From]
        $UpToValue = $Steps[$UpTo]

        $RepositoryDir = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($RepositoryDir)
        New-Item -Path $RepositoryDir -ItemType Directory -Force | Out-Null

        if (-not $JournalDir) {
            $JournalDir = [System.IO.Path]::Combine([System.IO.Path]::GetTempPath(), [guid]::NewGuid().ToString())
        }
        else {
            $JournalDir = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($JournalDir)
        }
        New-Item -Path $JournalDir -ItemType Directory -Force | Out-Null

        Start-Activity 'Export'

        Write-Verbose "RepositoryDir: $RepositoryDir" -Verbose
        Write-Verbose "JournalDir: $JournalDir" -Verbose

        if ($FromValue -le $Steps.Resolve -and $UpToValue -ge $Steps.Resolve) {
            Resolve-AllProducts
        }

        if ($FromValue -le $Steps.Download -and $UpToValue -ge $Steps.Download) {
            Download-AllProducts
        }

        if ($FromValue -le $Steps.Cleanup -and $UpToValue -ge $Steps.Cleanup) {
            Invoke-Cleanup
        }

        Stop-Activity
    }
}

#-----------------------------------------------------------------------

$ErrorActionPreference = 'Stop'
$InformationPreference = 'Continue'

Import-Module "$PSScriptRoot\Activities.psm1" -Force -ErrorAction Stop

Export-ModuleMember -Function @('Export-AzsMarketplaceItem')
